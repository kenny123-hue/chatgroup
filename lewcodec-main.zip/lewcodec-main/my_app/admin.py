from django.contrib import admin
from .models import Search

# Register your models here.

admin.site.register(Search),
